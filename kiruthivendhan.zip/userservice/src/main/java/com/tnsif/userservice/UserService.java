package com.tnsif.userservice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserService {
    @Autowired
    private UserRepository repo;

    // Retrieve all users
    public List<User1> listAll() {
        return repo.findAll();
    }

    // Save a user (create or update)
    public User1 save(User1 user) {
        return repo.save(user);
    }

    // Retrieve a user by ID
    public Optional<User1> getUserById(int id) {
        return repo.findById(id);
    }

    // Update an existing user
    public void update(User1 user, int id) {
        if (repo.existsById(id)) {
            user.setId(id); // Assuming User1 has a method to set ID
            repo.save(user);
        } else {
            throw new RuntimeException("User not found with id: " + id);
        }
    }

    // Delete a user by ID
    public void delete(int id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
        } else {
            throw new RuntimeException("User not found with id: " + id);
        }
    }
}
