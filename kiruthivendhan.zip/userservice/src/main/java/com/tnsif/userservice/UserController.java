package com.tnsif.userservice;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")  // Enables requests from all origins (useful for testing)
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    // Get all users
    @GetMapping("/users")
    public List<User1> listAll() {
        return userService.listAll();
    }

    // Get user by ID
    @GetMapping("/users/{id}")
    public Optional<User1> getUserById(@PathVariable int id) {
        return userService.getUserById(id);
    }

    // Add a new user
    @PostMapping("/users")
    public void add(@RequestBody User1 user) {
        userService.save(user);
    }

    // Update an existing user by ID
    @PutMapping("/users/{id}")
    public void update(@RequestBody User1 user, @PathVariable int id) {
        userService.update(user, id);
    }

    // Delete a user by ID
    @DeleteMapping("/users/{id}")
    public void delete(@PathVariable int id) {
        userService.delete(id);
    }
}
